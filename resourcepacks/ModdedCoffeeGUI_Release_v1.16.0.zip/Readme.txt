PATCH NOTES

Release v1.16.0

	-Updated Spell Engine for later versions (By D1scoball)
	-Added Combat Roll (By D1scoball)
	-Added Client Sort (By D1scoball)
	-Added Brewin and Chewin (By D1scoball)

Release v1.15.2

	-Updated Immersive Overlays for later versions
	-Added JEI screen for cooking pot from Farmer's Delight
	-Added AtrributesLib (By RODRI556677)
	-Fixed a couple of inconsistencies for create (By RODRI556677)
	-Changed JEI slot texture for Create and Farmer's Delight (Suggested by RODRI556677)
	-Fixed sawmill scrollbar (By RODRI556677)

Release v1.15.1

	-Removed the inner line from Inventorios expanded inventory

Release v1.15.0

	-Fixed curios scrollbar size (By RODRI556677)
	-Fixed inconsistencies with all progress arrows
	-Fixed stray pixels in Waystones warp plate
	-Updated Spell Engine spell binding buttons
	-Updated Spell Engine book slot icon
	-Updated Travelers Backpack fluid slot icon
	-Added Advanced Loot Info (By RODRI556677)
	-Added Inventorio (By RODRI556677)

Release v1.14.1

	-Fixed Create "Linked Controller" input order

Release v1.14.0

	-Updated inventory slot icons to match the main pack
	-Added Colorful Hearts
	-Added Ice and Fire
	-Added Immersive Overlays
	-Added More Heart Types
	-Added Overflowing Bars
	-Added Parcool (By Lyhaz)
	-Added Penchant
	-Added Shulkerbox Tooltip
	-Added Stonecutting Upgrade (By JustxAustin)
	-Added Tool Pouch

Release v1.13.0

	-Added Animal Feeding Trough (By JustxAustin)
	-Added AlcoCraft+ (By JustxAustin)

Release v1.12.1

	-Fixed TrashSlot not working on newer versions

Release v1.12.0

	-Added Macaw's Furniture Mods
	-Added Rechiseled
	-Added Chisel (chisel2gui.png by JustxAustin)
	-Added Chisel Reborn (chisel2gui.png by JustxAustin)
	-Added Clayworks (By ElseyDracul)
	-Added FTBLibrary (By ElseyDracul)
	-Added FTBTeams (By ElseyDracul)
	-Added Net Music (By ElseyDracul)
	-Added Sawmill (By ElseyDracul)
	-Added Tarot Cards (By ElseyDracul)
	-Added Woodworks (By ElseyDracul)

Release v1.11.0

	-Added Cosmetic Armor Reworked (By Lyhaz)
	-Added Enchanting System Overhaul (By Lyhaz)
	-Added Origins (By Lyhaz)

Release v1.10.0

	-Updated Curios
	-Added Artifacts
	-Added Modular Backpacks
	-Added Relics
	-Added YYZs Backpack

	-Changed version label (v[MainVersion].[ContentNumber].[MinorFixes])

Release v1.0.8

	-Changed hunger to coffee beans in Appleskin, Farmers Delight, LevelZ, Sophisticated Core and Travelers Backpack
	-Changed Pack Icon
	-Added Chipped
	-Added Crafting Tweaks
	-Added Trash Cans

Release v1.0.7

	-Remade buttons to match Coffee GUI v2.1.0
	-A lot of minor things that I forgot to write down

	-Added Runes
	-Added Immersive Aircraft
	-Added Immersive Furniture
	-Added Immersive Melodies
	-Added Immersive Paintings

Release v1.0.6

	-Added Create
	-Added Farmers Delight
	-Added Quark
	-Added Quark Oddities
	-Added Supplementaries
	-Added Waystones
	-Added Let's Do Mods:
		-Let's Do Bakery - Farm&Charm Compat
		-Let's Do Beachparty
		-Let's Do Candlelight - Farm&Charm Compat
		-Let's Do Farm & Charm
		-Let's Do HerbalBrews
		-Let's Do Meadow
		-Let's Do NetherVinery
		-Let's Do Vinery

Release v1.0.5

	-Added textures for Accesorify (Doesn't work but textures are there)
	-Added Easy Shulker Boxes
	-Added Inventory Management
	-Added Inventory Sort
	-Added Inventory Sorter
	-Added Lightweight Inventory Sorting
	-Added Nemo's Inventory Sorting
	-Added Sort It Out
	-Added Spell Engine
	-Added Terrastorage
	-Added Utility Belt

Release v1.0.4

	-Added Accessories (and Owo-lib)
	-Added Corpse
	-Added Easy Anvil
	-Added Easy Magic
	-Added Easy Shulker Boxes (For some reason it doesn't work)
	-Added Polymorph
	-Added Trashslot

	-Added Resource Backpack's (By Motherose)
	-Added Trade Cycling (Original texture by Motherose, remade by me)

Release v1.0.3

	-Added JobsAddon
	-Added LevelZ
	-Added LibZ
	-Added PartyAddon
	-Added Simple Radio
	-Added Simple Voice Chat
	-Added Storage Drawers
	-Added Tom's Simple Storage

	-Updated Cursors Extended

Release v1.0.2

	-Added Backpacked
	-Added Inmis
	-Added Sophisticated Core (works for both Sophisticated Backpacks and Sophisticated Storage)
	-Added Traveler's Backpack

Release v1.0.1

	-Added EMI
	-Added JEI
	-Added REI

Release v1.0.0

	-Added AppleSkin
	-Added Curios
	-Added Cursors Extended
	-Added Item Swapper
	-Added Mod Menu
	-Added Trinkets

Do not distribute or republish anywhere else without permission, the only page that offers this resourcepack is Modrinth and Planet Minecraft, and only by me. If you see any version of this resourcepack anywhere else, do not download, it was uploaded without my supervision and could be dangerous.

Modrinth: https://modrinth.com/resourcepack/modded-coffee-gui
Curseforge: https://www.curseforge.com/minecraft/texture-packs/modded-coffee-gui
Planet Minecraft: https://www.planetminecraft.com/texture-pack/dark-coffe-gui/
Ko-Fi (if you want 👉👈): https://ko-fi.com/restlesspip